"""Cold raw-loader first-action control in a fresh main-thread process."""
import copy
import importlib.util
import json
import argparse
import threading
import time
from pathlib import Path

root = Path(__file__).resolve().parent


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


parser = argparse.ArgumentParser()
parser.add_argument('archive', type=Path)
parser.add_argument('output', type=Path)
parser.add_argument('--contract', type=Path, default=(
    root / 'contract/revenue/kaggriculture/cloud-execution-lab/reference/evaluator/official.py'))
parser.add_argument('--engine-dir', type=Path,
                    default=Path('/workspace/scratch/a958dc9af03f/engine-artifact/engine'))
args = parser.parse_args()
archive = args.archive.resolve()
output = args.output.resolve()

official = load(args.contract.resolve(),
                'main_smoke_contract')
evaluator = load(archive / 'checks/reference/evaluator/evaluate.py', 'main_smoke_evaluator')
loader = archive / 'checks/reference/evaluator/loader.py'
engine, engine_hashes = evaluator.get_engine(args.engine_dir.resolve(), loader)
cfg = evaluator.Struct({key: value.get('default') if isinstance(value, dict) else value
                        for key, value in engine.specification['configuration'].items()})
cfg.seed = 9922999
env = evaluator.Struct(configuration=cfg, done=False, info={})
state = [evaluator.Struct(observation=evaluator.Struct(), action={}, status='ACTIVE', reward=0)
         for _ in range(2)]
engine.interpreter(state, env)
state[0].observation.step = 0
agent = official.make_agent(archive / 'main.py')
started = time.perf_counter()
action = agent(copy.deepcopy(state[0].observation), copy.deepcopy(cfg))
result = {
    'thread_ident': threading.get_ident(),
    'main_thread_ident': threading.main_thread().ident,
    'seconds': time.perf_counter() - started,
    'action': action,
    'engine_ref': evaluator.ENGINE_REF,
    'engine_sha256': engine_hashes,
}
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
