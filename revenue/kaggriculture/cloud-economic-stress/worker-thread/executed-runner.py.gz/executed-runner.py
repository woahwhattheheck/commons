"""Run every raw candidate action in one persistent non-main worker thread."""
import argparse
import copy
import importlib.util
import json
import statistics
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DEFAULT_CONTRACT = ROOT / 'contract/revenue/kaggriculture/cloud-execution-lab/reference/evaluator/official.py'
DEFAULT_ENGINE_DIR = Path('/workspace/scratch/a958dc9af03f/engine-artifact/engine')


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--archive-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--contract', type=Path, default=DEFAULT_CONTRACT)
    parser.add_argument('--engine-dir', type=Path, default=DEFAULT_ENGINE_DIR)
    parser.add_argument('--seed', type=int, default=9922999)
    args = parser.parse_args()
    raw = args.archive_root.resolve() / 'main.py'
    evaluator_path = args.archive_root.resolve() / 'checks/reference/evaluator/evaluate.py'
    loader_path = args.archive_root.resolve() / 'checks/reference/evaluator/loader.py'
    official = load(args.contract.resolve(), 'threaded_episode_contract')
    evaluator = load(evaluator_path, 'threaded_episode_evaluator')
    engine, engine_hashes = evaluator.get_engine(args.engine_dir.resolve(), loader_path)
    cfg = evaluator.Struct({key: value.get('default') if isinstance(value, dict) else value
                            for key, value in engine.specification['configuration'].items()})
    cfg.seed = args.seed
    env = evaluator.Struct(configuration=cfg, done=False, info={})
    state = [evaluator.Struct(observation=evaluator.Struct(), action={}, status='ACTIVE', reward=0)
             for _ in range(2)]
    engine.interpreter(state, env)
    if cfg.get('seed') is not None:
        raise ValueError('Engine seed leaked to agent configuration')
    candidate = official.make_agent(raw)
    calls = []
    trace = __import__('hashlib').sha256()
    daily = []
    turns = []
    failure = None
    main_ident = threading.main_thread().ident

    def invoke(observation, configuration):
        started = time.perf_counter()
        action = candidate(observation, configuration)
        return action, time.perf_counter() - started, threading.get_ident()

    episode_started = time.perf_counter()
    with ThreadPoolExecutor(max_workers=1, thread_name_prefix='kaggle-agent-worker') as pool:
        for step in range(int(cfg.episodeSteps)):
            state[0].observation.step = step
            state[1].observation.step = step
            state[0].observation.remainingOverageTime = 0
            state[1].observation.remainingOverageTime = 0
            outer_started = time.perf_counter()
            future = pool.submit(invoke, copy.deepcopy(state[0].observation), copy.deepcopy(cfg))
            try:
                candidate_action, call_seconds, worker_ident = future.result(timeout=1.0)
            except BaseException as error:
                failure = {'step': step, 'type': type(error).__name__, 'message': str(error)}
                break
            outer_seconds = time.perf_counter() - outer_started
            if worker_ident == main_ident:
                failure = {'step': step, 'type': 'ProtocolError', 'message': 'candidate ran on main thread'}
                break
            calls.append({'step': step, 'call_seconds': call_seconds,
                          'outer_seconds': outer_seconds, 'worker_ident': worker_ident})
            rival_action = engine.starter_agent(copy.deepcopy(state[1].observation))
            actions = [candidate_action, rival_action]
            state[0].action, state[1].action = actions
            engine.interpreter(state, env)
            bank = [float(state[0].observation.farms[i]['money']) for i in range(2)]
            turns.append({'step': step, 'actions': actions, 'bank': bank})
            trace.update(evaluator.encoded({'step': step, 'actions': actions, 'bank': bank}))
            done = all(s.status == 'DONE' for s in state)
            if (step + 1) % int(cfg.turnsPerDay) == 0 or done:
                daily.append({'step': step, 'bank': bank})
            if done:
                env.done = True
                break
    trace.update(evaluator.encoded([s.observation for s in state]))
    complete = failure is None and all(s.status == 'DONE' for s in state)
    scores = [s.reward for s in state] if complete else None
    result = {
        'scope': 'all candidate calls in one persistent non-main worker thread',
        'raw_entrypoint': str(raw),
        'engine_ref': evaluator.ENGINE_REF,
        'engine_sha256': engine_hashes,
        'seed': args.seed,
        'candidate_seat': 0,
        'opponent': 'official_starter',
        'status': 'complete' if complete else 'failed',
        'failure': failure,
        'steps': len(calls),
        'scores': scores,
        'candidate_calls': len(calls),
        'worker_thread_ids': sorted({c['worker_ident'] for c in calls}),
        'main_thread_id': main_ident,
        'max_call_seconds': max((c['call_seconds'] for c in calls), default=None),
        'mean_call_seconds': statistics.mean(c['call_seconds'] for c in calls) if calls else None,
        'max_outer_seconds': max((c['outer_seconds'] for c in calls), default=None),
        'mean_outer_seconds': statistics.mean(c['outer_seconds'] for c in calls) if calls else None,
        'episode_wall_seconds': time.perf_counter() - episode_started,
        'daily_bank': daily,
        'turns': turns,
        'trace_sha256': trace.hexdigest(),
    }
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    return 0 if complete else 1


if __name__ == '__main__':
    raise SystemExit(main())
