"""Retain current public observations around an unchanged pack adapter.

Capture metadata never reaches the delegate. The exact returned action is kept.
Capture overhead remains inside the existing native deadline.
"""
from pathlib import Path
import json
import os
import sys
import tempfile

PUBLIC_KEYS = ('step', 'player', 'farms', 'market', 'town')


def wrap(delegate, directory):
    directory = Path(directory)
    calls = 0
    stream = None

    def agent(observation, configuration=None):
        nonlocal calls, stream
        step = observation['step']
        if stream is None:
            stream = tempfile.NamedTemporaryFile(mode='w', prefix='actor-', suffix='.jsonl', dir=directory, delete=False)
            event = {'event': 'start', 'pid': os.getpid(), 'player': observation['player'], 'first_step': step, 'path': stream.name}
            with (directory / 'order.jsonl').open('a') as order:
                order.write(json.dumps(event, sort_keys=True) + '\n')
            stream.write(json.dumps(event, sort_keys=True) + '\n')
            stream.flush()
        # Copy before delegation; private state and configuration are excluded.
        public = None
        if step in (144, 648):
            public = json.loads(json.dumps({key: observation[key] for key in PUBLIC_KEYS}, sort_keys=True))
        action = delegate(observation, configuration)
        calls += 1
        if step in (144, 648, 718):
            router = sys.modules.get('r04_full_router')
            policy = getattr(router, '_POLICY', None)
            state = getattr(policy, 'players', {}).get(observation['player'])
            event = {'event': 'boundary', 'step': step, 'player': observation['player'], 'calls': calls,
                     'public_observation_before': public, 'plan_after': getattr(state, 'plan', None)}
            stream.write(json.dumps(event, sort_keys=True, separators=(',', ':')) + '\n')
            stream.flush()
        return action
    return agent
