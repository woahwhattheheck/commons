import importlib.util as _util
_runner = None
def agent(observation, configuration=None):
    global _runner
    if _runner is None:
        spec = _util.spec_from_file_location('kag_pack_contract', '/workspace/scratch/e67ff728c8fb/commons-c00-native/revenue/kaggriculture/cloud-pack/official.py')
        module = _util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _runner = module.make_agent('/workspace/scratch/e67ff728c8fb/verification-13475/materialized/step-144/plan-08/a/payload/main.py')
    return _runner(observation, configuration or {})
