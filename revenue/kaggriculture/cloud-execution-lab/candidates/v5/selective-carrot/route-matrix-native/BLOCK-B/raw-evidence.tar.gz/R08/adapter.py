import importlib.util as _u
_s=_u.spec_from_file_location('route_base', '/workspace/scratch/e67ff728c8fb/native-block-b/R08/pack-adapter.py')
_base=_u.module_from_spec(_s)
_s.loader.exec_module(_base)
_s=_u.spec_from_file_location('route_capture', '/workspace/scratch/e67ff728c8fb/native-block-b/passive_capture.py')
_capture=_u.module_from_spec(_s)
_s.loader.exec_module(_capture)
agent=_capture.wrap(_base.agent, '/workspace/scratch/e67ff728c8fb/native-block-b/R08/snapshots')
