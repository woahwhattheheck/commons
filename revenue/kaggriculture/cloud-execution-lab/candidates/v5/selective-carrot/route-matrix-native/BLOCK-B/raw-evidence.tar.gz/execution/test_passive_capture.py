import copy, json, tempfile, unittest
from pathlib import Path
from passive_capture import wrap
class CaptureContracts(unittest.TestCase):
 def test_argument_and_action_identity_no_private_retention(self):
  with tempfile.TemporaryDirectory() as directory:
   observation={'step':144,'player':1,'farms':[{'money':4},{'money':5}],'market':{'X':1},'town':{'shops':[]},'private':{'shed':{'SECRET':9}}}; before=copy.deepcopy(observation); config={'seed':None}; action={'farmer':['PASS']}
   def delegate(o,c):
    self.assertIs(o,observation);self.assertIs(c,config);self.assertEqual(o,before);return action
   got=wrap(delegate,directory)(observation,config)
   self.assertIs(got,action);self.assertEqual(observation,before)
   rows=[json.loads(x) for x in next(Path(directory).glob('actor-*.jsonl')).read_text().splitlines()]
   self.assertNotIn('private',rows[1]['public_observation_before']);self.assertNotIn('SECRET',json.dumps(rows));self.assertEqual(rows[1]['public_observation_before']['farms'],before['farms'])
 def test_pre_call_copy_survives_delegate_mutation(self):
  with tempfile.TemporaryDirectory() as directory:
   obs={'step':144,'player':0,'farms':[{'money':4}],'market':{},'town':{}}
   def delegate(o,c):o['farms'][0]['money']=0;return {}
   wrap(delegate,directory)(obs,{})
   rows=[json.loads(x) for x in next(Path(directory).glob('actor-*.jsonl')).read_text().splitlines()]
   self.assertEqual(rows[1]['public_observation_before']['farms'][0]['money'],4)
 def test_delegate_failure_is_preserved(self):
  with tempfile.TemporaryDirectory() as directory:
   def delegate(o,c):raise RuntimeError('delegate failure')
   with self.assertRaisesRegex(RuntimeError,'delegate failure'):wrap(delegate,directory)({'step':0,'player':0},{})
 def test_distinct_actor_files_and_local_call_count(self):
  with tempfile.TemporaryDirectory() as directory:
   for player in (0,1):
    agent=wrap(lambda o,c:{},directory)
    for step in (0,718):agent({'step':step,'player':player},{})
   self.assertEqual(len(list(Path(directory).glob('actor-*.jsonl'))),2)
   order=[json.loads(x) for x in (Path(directory)/'order.jsonl').read_text().splitlines()]
   self.assertEqual([x['player'] for x in order],[0,1])
   for p in Path(directory).glob('actor-*.jsonl'):self.assertEqual(json.loads(p.read_text().splitlines()[-1])['calls'],2)
if __name__=='__main__':unittest.main()
