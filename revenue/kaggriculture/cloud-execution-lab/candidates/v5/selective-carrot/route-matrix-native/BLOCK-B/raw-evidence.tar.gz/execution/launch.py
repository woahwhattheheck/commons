from pathlib import Path
import datetime,hashlib,json,os,sys
r=Path('/workspace/scratch/e67ff728c8fb/native-block-b')/sys.argv[1]
c=json.loads((r/'INPUT-CUSTODY.json').read_text())
for p,h in c['inputs'].items():
 if hashlib.sha256(Path(p).read_bytes()).hexdigest()!=h:raise SystemExit('Input changed: '+p)
if (r/'report.json').exists():raise SystemExit('Completed report exists; refusing rerun')
record={'row':c['row'],'pid':os.getpid(),'workspace':str(r),'candidate_archive_sha256':c['candidate_archive_sha256'],'input_custody_sha256':hashlib.sha256((r/'INPUT-CUSTODY.json').read_bytes()).hexdigest(),'prepared_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':c['command'],'status':'WAITING_FOR_START'}
p=r/'LAUNCH.json'
with p.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in record.items() if k!='command'}),flush=True)
if input()!='START':raise SystemExit('Launch not released')
record['started_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();record['status']='EXECUTING';p.write_text(json.dumps(record,indent=2)+'\n')
fd=os.open(str(r/'stdout.jsonl'),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o644);os.dup2(fd,1);os.dup2(fd,2);os.close(fd)
os.execv(c['command'][0],c['command'])
