from pathlib import Path
import hashlib, importlib.util, json, sys
W=Path('/workspace/scratch/e67ff728c8fb'); R=W/'native-block-b'; C=W/'c00-native'; KG=W/'commons-c00-native/revenue/kaggriculture'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('existing_pack',KG/'cloud-pack/pack.py'); pack=importlib.util.module_from_spec(spec);spec.loader.exec_module(pack)
base=json.loads((C/'INPUT-CUSTODY.json').read_text())
for plan in range(5,9):
 name=f'R{plan:02}'; dest=R/name;dest.mkdir(exist_ok=False);(dest/'snapshots').mkdir()
 material=W/f'verification-13475/materialized/step-144/plan-{plan:02}/a'
 archive=material/'candidate.tar.gz'; payload=material/'payload'; manifest=material/'payload-manifest.json'; m=json.loads(manifest.read_text())
 assert m['plan_index']==plan and m['selection_step']==144 and m['terminal_plan']==2 and m['final_plan_step']==648
 assert m['changed_members']==['r04_full_router.py'] and len(m['files'])==92
 assert m['candidate_archive_sha256']==sha(archive)
 for p,h in m['files'].items():assert sha(payload/p)==h
 base_adapter=dest/'pack-adapter.py';pack.write_adapter(base_adapter,payload/'main.py')
 code="import importlib.util as _u\n"
 for label,path in [('base',base_adapter),('capture',R/'passive_capture.py')]:
  code+=f"_s=_u.spec_from_file_location('route_{label}', {str(path)!r})\n_{label}=_u.module_from_spec(_s)\n_s.loader.exec_module(_{label})\n"
 code+=f"agent=_capture.wrap(_base.agent, {str(dest/'snapshots')!r})\n"
 adapter=dest/'adapter.py';adapter.write_text(code)
 cmd=list(base['commands']['production']);cmd[cmd.index('--candidate')+1]=str(adapter)+'::agent';cmd[cmd.index('--output')+1]=str(dest/'report.json')
 inputs=dict(base['inputs']);inputs.update({str(payload/p):h for p,h in m['files'].items()})
 for p in [archive,manifest,base_adapter,adapter,R/'passive_capture.py']:inputs[str(p)]=sha(p)
 receipt={'schema':'titan-route-native-input-custody/v1','row':name,'plan':plan,'selection_step':144,'terminal_plan':2,'candidate_archive_sha256':m['candidate_archive_sha256'],'candidate_manifest':str(manifest),'candidate_manifest_sha256':sha(manifest),'source_head':'b4f4feb273ee117dec76f4f586040e1e4c307eb0','source_main_readback':'39e59dc547d11615054c1fc22d0245a28b57340e','evaluator_source_commit':base['source_commit'],'command':cmd,'inputs':inputs,'scheduled_games':8,'authoritative_control_workspace':'/workspace/scratch/8cef44d5af4f/native-c00','authoritative_control_slack_ts':'1789255175.585289','snapshot_capture':{'source':str(R/'passive_capture.py'),'sha256':sha(R/'passive_capture.py'),'contract':'Public pre-call observations at144/648; unchanged delegate args/action identity; overhead included in native action deadline; sequential evaluator game order joins8 actor records to8 report games.'}}
 (dest/'INPUT-CUSTODY.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
 print(name,m['candidate_archive_sha256'],'custody',sha(dest/'INPUT-CUSTODY.json'))
