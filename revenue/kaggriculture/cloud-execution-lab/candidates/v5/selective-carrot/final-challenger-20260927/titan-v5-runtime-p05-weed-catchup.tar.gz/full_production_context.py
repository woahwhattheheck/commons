configuration = {}
