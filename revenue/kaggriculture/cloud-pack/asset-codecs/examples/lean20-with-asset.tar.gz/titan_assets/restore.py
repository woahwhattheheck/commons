"""Restore the original asset once before using it; supplied asset license applies."""
from pathlib import Path
import sys, time, json, resource, importlib.util
def restore(destination):
    root = Path(__file__).resolve().parent
    spec = importlib.util.spec_from_file_location("_kag_local_asset_codec", root / "asset_codec.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.decode_file(root / "asset.kac", destination, max_bytes=15645)
if __name__ == "__main__":
    start = time.perf_counter()
    result = restore(sys.argv[1])
    use = resource.getrusage(resource.RUSAGE_SELF)
    result.update(operation_seconds=time.perf_counter()-start,
        process_cpu_seconds=use.ru_utime+use.ru_stime,
        peak_rss_kib=use.ru_maxrss/(1024 if sys.platform=="darwin" else 1))
    print(json.dumps(result))
