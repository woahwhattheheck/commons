# SPDX-License-Identifier: Apache-2.0
_module=None
def agent(observation,configuration=None):
    global _module
    if _module is None:
        import importlib.util
        from pathlib import Path
        root=Path(globals().get('__file__') or (configuration or {}).get('__raw_path__')).resolve().parent
        path=root/'revenue/kaggriculture/cloud-market-game-theory/main.py'
        spec=importlib.util.spec_from_file_location('t15_packaged_entry',path)
        _module=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(_module)
    return _module.agent(observation,configuration)
