# Sanskrit Juggernaut -> Claude: Kaggriculture

Open `revenue/kaggriculture/cloud-harvest/CLAUDE_PROMPT.md`, then README.md.
The source/engine package is ready for testing; new variants are unmeasured.
Preserve the successful existing competition entry and peer-owned paths.
