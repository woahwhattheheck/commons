"""Contract tests for Claude to run against the real pinned interpreter.

Engine files must already be prepared; absence is an error, never a skipped pass.
"""
import copy
import os
from pathlib import Path
import unittest
import run_study
import variants


class HarvestContracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ev = run_study.load(variants.HERE.parent / "cloud-eval/evaluate.py",
                               "harvest_test_evaluator")
        cls.engine, _ = cls.ev.get_engine(Path(os.environ["KAG_EVAL_ENGINE_DIR"]))

    def module(self, name):
        namespace = {}
        exec(compile(variants.build(name), name + ".py", "exec"), namespace)
        return namespace

    def initial(self, step=0):
        cfg = self.ev.Struct({k: v.get("default") if isinstance(v, dict) else v
                             for k, v in self.engine.specification["configuration"].items()})
        cfg.seed = 17
        env = self.ev.Struct(configuration=cfg, done=False, info={})
        state = [self.ev.Struct(observation=self.ev.Struct(), action={},
                               status="ACTIVE", reward=0) for _ in range(2)]
        self.engine.interpreter(state, env)
        for s in state:
            s.observation.update(step=step, day=step // cfg.turnsPerDay,
                                 hour=step % cfg.turnsPerDay)
        return state, env

    def test_crop_table_matches_official_maturity_and_yield(self):
        for crop, (_, first, mature, maximum) in self.module("crop_timing")["CROPS"].items():
            official = self.engine.CROPS[crop]
            self.assertEqual((first, mature, maximum),
                             (official["first_yield_day"], official["max_yield_day"],
                              official["max_yield"]))

    def test_public_observation_is_not_mutated(self):
        state, env = self.initial()
        obs = state[0].observation
        before = copy.deepcopy(obs)
        for name in variants.VARIANTS:
            action = self.module(name)["agent"](obs, env.configuration)
            self.assertEqual(obs, before)
            self.assertLessEqual(len(action["market"]), 10)

    def test_last_turn_drop_produces_real_cash(self):
        state, env = self.initial(718)
        obs = state[0].observation
        obs.private["inventories"][0] = {"EGG": 4}
        before = obs.farms[0]["money"]
        state[0].action = self.module("combined")["agent"](obs, env.configuration)
        self.assertEqual(state[0].action["farmer"], ["DROP"])
        self.engine.interpreter(state, env)
        self.assertEqual(state[0].status, "DONE")
        self.assertGreater(state[0].reward, before)
        self.assertEqual(obs.private["inventories"][0], {})
        self.assertEqual(obs.private["shed"].get("EGG", 0), 0)

    def test_two_remaining_actions_harvest_then_cash_out(self):
        state, env = self.initial(717)
        obs = state[0].observation
        x, y = obs.farms[0]["farmer"]
        animal = self.engine._new_animal("GOOSE", 0)
        animal.update(yield_units=4, fed_today=True, cared_today=True,
                      fertilizer_available=False)
        obs.farms[0]["tiles"][y][x] = animal
        agent = self.module("terminal_routes")["agent"]
        state[0].action = agent(obs, env.configuration)
        self.assertEqual(state[0].action["farmer"], ["HARVEST"])
        self.engine.interpreter(state, env)
        before = obs.farms[0]["money"]
        obs.step = 718
        state[0].action = agent(obs, env.configuration)
        self.assertEqual(state[0].action["farmer"], ["DROP"])
        self.engine.interpreter(state, env)
        self.assertGreater(state[0].reward, before)

    def test_same_turn_sale_uses_actual_deposit(self):
        state, env = self.initial()
        obs = state[0].observation
        obs.private["inventories"][0] = {"EGG": 12}
        state[0].action = self.module("same_turn_sales")["agent"](obs, env.configuration)
        self.assertEqual(state[0].action["farmer"], ["DROP"])
        self.assertIn(["SELL", "EGG", 12], state[0].action["market"])
        self.engine.interpreter(state, env)
        self.assertEqual(obs.private["inventories"][0], {})
        self.assertEqual(obs.private["shed"].get("EGG", 0), 0)

    def test_shed_overflow_is_not_quoted_as_saleable(self):
        sell = self.module("same_turn_sales")["deposit_sales"]
        orders = sell([], [["DROP"]], [(4, 4)], [{"MILK": 2}],
                      {"EGG": 99}, {(4, 4)}, 100, 0, True)
        self.assertEqual(orders, [["SELL", "EGG", 99], ["SELL", "MILK", 1]])

    def test_distant_carried_goods_are_not_saleable(self):
        sell = self.module("same_turn_sales")["deposit_sales"]
        self.assertEqual(sell([], [["WEST"]], [(1, 1)], [{"MILK": 2}],
                              {}, {(4, 4)}, 100, 0, True), [])

    def test_pickup_is_applied_before_feed_reserve(self):
        sell = self.module("same_turn_sales")["deposit_sales"]
        self.assertEqual(sell([], [["PICKUP", "WHEAT", 3]], [(4, 4)], [{}],
                              {"WHEAT": 10}, {(4, 4)}, 100, 2, False),
                         [["SELL", "WHEAT", 3]])


if __name__ == "__main__":
    unittest.main()
