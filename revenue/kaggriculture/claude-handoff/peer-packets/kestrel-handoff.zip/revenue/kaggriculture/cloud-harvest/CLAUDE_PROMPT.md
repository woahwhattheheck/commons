# Prompt for Sanskrit Juggernaut to send to Claude

Bryce directed: "Give all stuff to sanskrit juggernaut so it can prompt claude
for testing and running simulations". Continue the existing Kaggriculture work
from this complete handoff. Your assigned job is actual contract testing and
official-engine simulation, followed by an evidence-backed candidate delivery.
Use your existing Claude session and existing cloud compute.

Read `revenue/kaggriculture/cloud-harvest/README.md` and
`handoff_manifest.json` first. This directory contains unmeasured hypotheses,
not a preselected winner. Existing lean20, Euler28, compact22, original36,
the engine loader, independent evaluator, source study, diagnostics, licenses,
previous measured results and exact source hashes are supplied or linked.

1. Verify the manifest and official engine blobs. Review the proposed source
   diffs in `variants.py`; verify crop timing, inclusive final-action arithmetic,
   DROP overflow, pickup sequencing, reserved wheat and the ten-market-order
   cap against the real interpreter. No new network/model/API dependency in
   any agent. Do not expose private opponent observations or the world seed.
2. Run `test_variants.py` and the existing evaluator tests with a verified engine
   cache. Fix any real failure inside `cloud-harvest/`, preserving the prior
   source and creating a new explicit manifest before simulations. Report the
   exact test counts; missing engine tests must not become silent passes.
3. Run the declared 80 development games using `run_study.py`. It includes an
   unchanged control and preserves every result in a resumable source-bound
   journal. Choose from development only. If unchanged lean20 wins, retain it
   and report that result honestly; do not fabricate an improvement.
4. Freeze the selected source and selection record, then run the declared
   64 validation games and four replays. Confirm the proposed validation seeds
   have not been used by another active peer. Never adjust the algorithm from
   validation feedback and then reuse those seeds as unseen data. A meaningful
   next iteration receives new candidate IDs, preserved previous evidence and
   a separately reserved validation set.
5. Report wins/ties/losses and mean/minimum margin by opponent, both player
   seats, paired-seed uncertainty, every crash/timeout, maximum decision/RPC
   time, worker RSS, exact interpreter/agent/evaluator hashes and replay checks.
   Inspect low-margin games for crop aging, harvest backlog, wasted return
   trips, discarded goods, feed availability and order pressure. Reuse
   `cloud-market/diagnostics.py` rather than changing the engine. Instrumented
   traces must equal the original trajectories before drawing conclusions.
6. If evidence supports promotion, export the exact selected stdlib `main.py`,
   licenses, results and a deterministic submission archive. Otherwise preserve
   lean20 and ship the usable tests/simulations and honest rejected hypotheses.
   Land coherent unique changes on current Commons main through non-force
   integration, read back the exact bytes, and post the result in the existing
   Kaggriculture thread. Include a copyable exact command and link for the
   existing account session to evaluate the next submission.

Existing successful Kaggle entry: tokenjunkielabs notebook v2,
scriptVersionId347872961, reported Success/Complete with initial score600.0.
Root/account session retains replacement-submission ownership. Do not fork a
second account, registration, team or notebook. Euler and ASTRA's paths retain
their owners; this handoff transfers only `cloud-harvest/` work. No new paid
service/compute purchase or Cursor spend is authorized by this handoff.
Do not install llama.cpp or wrappers. Preserve all owner and upstream licenses;
coordinate required public code sharing with the existing account session.

Finish with actual source/test/simulation receipts. Do not call source delivery
a hosted submission, tournament rank, prize, or cash earnings. Relay the result
back through Sanskrit Juggernaut and the existing project thread.
