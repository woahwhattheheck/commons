"""Claude's offline simulation entry point; no simulations run on import.

Reuses ASTRA-WORK's official-engine process isolation, resumable journal and
paired statistics. Development chooses one exact candidate before validation.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import variants

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
DEV_SEEDS = [1901, 5087, 12011, 30011]
VALIDATION_SEEDS = [80021, 80039, 80051, 80071, 80077, 80099, 80107, 80111]


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_handoff():
    manifest = json.loads((HERE / "handoff_manifest.json").read_text())
    for path, expected in manifest["source_sha256"].items():
        if digest(ROOT / path) != expected:
            raise ValueError("Handoff source changed: " + path)
    return manifest


def run(engine_dir, output, phase):
    engine_dir, output = Path(engine_dir).resolve(), Path(output).resolve()
    manifest = verify_handoff()
    shared = load(HERE.parent / "cloud-market/study.py", "harvest_shared_study")
    ev = shared.evaluator()
    engine, engine_hashes = ev.get_engine(engine_dir)
    candidate_hashes = variants.generate(output / "generated")
    rivals = {name: str(HERE / "baselines" / (name + ".py"))
              for name in ("lean20", "euler28")}
    names, seeds = list(variants.VARIANTS), DEV_SEEDS
    selection = None
    if phase == "validation":
        selection = json.loads((output / "selection.json").read_text())
        if selection["handoff_manifest_sha256"] != digest(HERE / "handoff_manifest.json"):
            raise ValueError("Selection belongs to a different handoff")
        name = selection["variant"]
        if candidate_hashes[name] != selection["candidate_sha256"]:
            raise ValueError("Selected candidate changed before validation")
        if name == "lean20_control":
            raise ValueError("Development selected the incumbent; no new candidate to validate")
        names, seeds = [name], VALIDATION_SEEDS
        rivals.update(compact22=str(HERE / "baselines/compact22.py"),
                      official_starter="official_starter")
    contract = {
        "phase": phase, "seeds": seeds, "seats": [0, 1],
        "manifest_sha256": digest(HERE / "handoff_manifest.json"),
        "runner_sha256": digest(__file__), "python": sys.version,
        "candidate_sha256": candidate_hashes, "engine_sha256": engine_hashes,
        "engine_ref": ev.ENGINE_REF, "evaluator_sha256": digest(ev.__file__),
        "loader_sha256": digest(ev.LOADER), "shared_study_sha256": digest(shared.__file__),
        "opponents": {n: ev.ENGINE_REF if p == "official_starter" else digest(p)
                      for n, p in rivals.items()},
        "agent_rng_seed": 20260907, "action_rpc_seconds": 1.0,
        "game_timeout_seconds": 120.0, "episode_steps": 720,
    }
    journal = shared.Journal(output / (phase + ".jsonl"), contract)
    rows = []
    for name in names:
        candidate = str(output / "generated" / (name + ".py"))
        for opponent, rival in rivals.items():
            for seed in seeds:
                for seat in (0, 1):
                    key = f"{name}/{opponent}/{seed}/{seat}"
                    if key not in journal.rows:
                        pair = [candidate, rival] if seat == 0 else [rival, candidate]
                        result = ev.play(engine, pair, engine_dir, ev.LOADER, seed, seat)
                        result.update(variant=name, opponent=opponent)
                        journal.put(key, result)
                    result = journal.rows[key]
                    rows.append(result)
                    print(json.dumps({k: result[k] for k in
                        ("variant", "opponent", "seed", "candidate_seat", "status", "scores")}),
                        flush=True)
    summary = {name: {opponent: shared.paired_summary([
        r for r in rows if r["variant"] == name and r["opponent"] == opponent])
        for opponent in rivals} for name in names}
    report = {"contract": contract, "summary": summary, "games": rows,
              "selection": selection, "method": manifest["evaluation_method"]}
    shared.write_json(output / (phase + ".json"), report)
    if any(row["status"] != "complete" or row["steps"] != 719 for row in rows):
        raise RuntimeError("Incomplete/failed game retained; no selection or success claim")
    if phase == "development":
        def rank(name):
            margins = [summary[name][opponent]["mean_margin"] for opponent in rivals]
            return min(margins), sum(margins) / len(margins), name
        selected = max(names, key=rank)
        selection = {"variant": selected, "candidate_sha256": candidate_hashes[selected],
                     "handoff_manifest_sha256": digest(HERE / "handoff_manifest.json"),
                     "development_report_sha256": digest(output / "development.json"),
                     "rule": "Maximize worst opponent mean margin, then overall mean, then name",
                     "promotion": "NOT_VALIDATED", "development_summary": summary[selected]}
        shared.write_json(output / "selection.json", selection)
        print("SELECTED " + json.dumps(selection), flush=True)
    else:
        candidate = str(output / "generated" / (names[0] + ".py"))
        replay_checks = []
        for opponent, rival in rivals.items():
            original = next(r for r in rows if r["opponent"] == opponent
                            and r["seed"] == seeds[0] and r["candidate_seat"] == 0)
            replay = ev.play(engine, [candidate, rival], engine_dir, ev.LOADER, seeds[0], 0)
            equal = (replay["status"] == "complete" and replay["scores"] == original["scores"]
                     and replay["trace_sha256"] == original["trace_sha256"])
            replay_checks.append({"opponent": opponent, "match": equal, "replay": replay})
        report["replays"] = replay_checks
        shared.write_json(output / "validation.json", report)
        if not all(check["match"] for check in replay_checks):
            raise RuntimeError("Replay mismatch; evidence retained")
        print("VALIDATION " + json.dumps(summary), flush=True)
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--engine-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--phase", choices=("development", "validation"), required=True)
    args = parser.parse_args()
    run(args.engine_dir, args.output, args.phase)
