# Kaggriculture handoff: Sanskrit Juggernaut -> Claude

**Owner-directed handoff; new variants are UNTESTED and UNMEASURED.**
Bryce's instruction: "Give all stuff to sanskrit juggernaut so it can prompt
claude for testing and running simulations". Start with [CLAUDE_PROMPT.md](CLAUDE_PROMPT.md).
This package hands off working source generation, contract tests and a simulation
runner, alongside the existing team's code and evidence. It does not promote a
new agent, replace the accepted entry, or claim delivery to an unverified inbox.

## Existing state to preserve

| Item | Exact source / state |
|---|---|
| Current team baseline | `baselines/lean20.py`; SHA256 `d9487c031b50ede06a706acc8bcb40e0b5a681d9b5e92c1a1a96492b26c2dd62` |
| Euler28 | `baselines/euler28.py`; SHA256 `acf541d46ceb2002caf0a3bba834109a92b755fb36afa4bda9e3d966665550ac` |
| Original36 and compact22 | Frozen in `baselines/`; compact22 is the original36 ablation, not a changing import |
| Official engine | Kaggle/kaggle-environments `28b6d8af3ce73926b3d0fda1410c1ddd8384ab8c` |
| Source snapshot for this handoff | Commons main `22cd224184b6c0d183d9aa2fc06d845ababfacac`; per-file hashes in `handoff_manifest.json` |
| Existing hosted submission | Team reports Kaggle version `347872961`, notebook v2, Success/Complete, initial public score 600.0; this handoff did not recheck the hosted page |
| Replacement submission owner | Existing root/account session; retain the working entry and coordinate any replacement there |

Lean20's prior reserved validation: 15/16 wins versus Euler28, mean +3,202.125
in-game coins; 15/16 versus compact22, +2,713; 16/16 versus original36 and starter.
These are prior official-interpreter local results, not results for this handoff.
Two documented losses remain. Prior studies' seed sets have already been observed.

Evidence: [lean20 PR9743](https://github.com/woahwhattheheck/commons/pull/9743),
[successful main run](https://github.com/woahwhattheheck/commons/actions/runs/34087144544),
[full delivery artifact10005701500](https://github.com/woahwhattheheck/commons/actions/runs/34087144544/artifacts/10005701500),
[Euler economics](../20260907-offline-agent/ECONOMICS.md),
[lean20 economics](../cloud-market/ECONOMICS.md).

## What Claude receives

`variants.py` generates five complete stdlib agents: unchanged lean20 control,
corrected crop timing/yield, tighter terminal routes, same-turn deposit sales,
and their combination. These hypotheses may lose. No candidate is named a
winner in advance.

The crop variant aligns the agent table with the actual interpreter: melon
first yield day10 / full yield day12, wheat max yield6 and carrot max yield4.
The terminal variant uses the inclusive final action count, retains a one-turn
return cushion, and reduces discretionary final-day deposit priority. The sales
variant projects the chosen pickup/drop sequence with the real shed capacity,
then quotes only goods in the shed; cash planning stays unchanged. Verify order
pressure and feed sufficiency rather than assuming these changes help.

`run_study.py` reuses ASTRA's process-isolated evaluator, crash-resumable journal
and paired-seed statistics read-only. It checks the source manifest, separates
development and validation, fingerprints every candidate, and compares complete
games only. It stores four validation replays outside the main sample.

## Run in existing cloud compute

No new dependency install is needed: Python 3.11+ standard library on Linux.
Work from the repository root (or the extracted bundle root):

```sh
python -B revenue/kaggriculture/cloud-eval/evaluate.py --prepare-engine /tmp/kag-harvest-engine
KAG_EVAL_ENGINE_DIR=/tmp/kag-harvest-engine python -B revenue/kaggriculture/cloud-harvest/test_variants.py
KAG_EVAL_ENGINE_DIR=/tmp/kag-harvest-engine python -B revenue/kaggriculture/cloud-eval/test_evaluator.py
python -B revenue/kaggriculture/cloud-harvest/run_study.py --engine-dir /tmp/kag-harvest-engine --output /tmp/kag-harvest-results --phase development
# Read selection.json. If lean20_control wins, retain it; do not call that an improvement.
python -B revenue/kaggriculture/cloud-harvest/run_study.py --engine-dir /tmp/kag-harvest-engine --output /tmp/kag-harvest-results --phase validation
```

Prepare the three hash-checked engine files once, then run tests/simulations with
network disabled in the existing cloud runner. The bundle may include an
`engine/` directory already verified against the same blobs; use that path and
omit the preparation step when present. The borrowed evaluator uses a stricter
one-second decision RPC limit than Kaggle's overage-time bank; it is not the
hosted Kaggle runner. Each full game must have 719 action rounds and two DONE
players with numeric final money scores. Do not count a crash/timeout as a win.

Development: seeds1901,5087,12011,30011; both seats; five variants against frozen
lean20 and Euler28: **80 games**. Select by maximum worst opponent mean margin,
then overall mean, then name, including the unchanged control as fallback.
Freeze `selection.json` and the selected bytes before validation.

Validation: seeds80021,80039,80051,80071,80077,80099,80107,80111; both seats;
one selected variant against lean20, Euler28, compact22 and official starter:
**64 games plus four exact replays**. These seeds were declared before this
handoff ran any games. Confirm peers have not already used them before treating
them as fresh. Never tune on these outcomes. Preserve rejected variants and
failed runs; use a new named iteration/journal and new validation seeds if code
changes. Existing journals reject changed source contracts.

For promotion, require actual contract passes, no failed games, matching replays,
positive mean margin versus lean20 and evidence that the improvement survives
both seats and seed-level analysis. Report the entire opponent table, worst
losses, confidence limitations, latency/RSS and in-game coins. These conditions
are evidence criteria, not a new human approval or submission gate.

## Ownership and communication

Euler owns `20260907-offline-agent/`; ASTRA-WORK owns `cloud-market/` and
`cloud-eval/`. KESTREL's additive `cloud-harvest/` scope is transferred for the
requested Sanskrit Juggernaut -> Claude test/simulation work. Reuse peer files
read-only and coordinate before editing their paths. Do not launch duplicate
sessions, registrations or competition teams.

Use the existing [Kaggriculture thread](https://tokenjunkielabs.slack.com/archives/C0BUY2GT8P9/p1788752325435209)
and [execution thread](https://tokenjunkielabs.slack.com/archives/C0BTB4SUCP9/p1788753053465569).
Main source landing, test results, hosted submission, rank and payout are
different states. Retain MIT OR CC-BY-4.0 attribution and upstream Apache-2.0.
The account session handles the venue's required public sharing and submission.
