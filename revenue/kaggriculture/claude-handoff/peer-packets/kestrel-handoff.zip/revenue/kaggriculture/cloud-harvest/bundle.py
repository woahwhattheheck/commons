"""Build an exact, portable handoff archive; never runs an agent or a game."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import zipfile
import run_study


def bundle(output, engine_dir=None):
    manifest = run_study.verify_handoff()
    files = {name: (run_study.ROOT / name).read_bytes()
             for name in manifest["source_sha256"]}
    relative = "revenue/kaggriculture/cloud-harvest/handoff_manifest.json"
    files[relative] = (run_study.HERE / "handoff_manifest.json").read_bytes()
    if engine_dir is not None:
        engine_dir = Path(engine_dir)
        ev = run_study.load(run_study.HERE.parent / "cloud-eval/evaluate.py", "bundle_evaluator")
        ev.verify_sources(engine_dir)
        license_path = engine_dir / "LICENSE"
        if not license_path.is_file():
            raise ValueError("Include Kaggle's pinned Apache-2.0 LICENSE with the engine")
        for name in (*ev.ENGINE_BLOBS, "LICENSE"):
            files["engine/" + name] = (engine_dir / name).read_bytes()
    files["START_HERE.md"] = (
        "# Sanskrit Juggernaut -> Claude: Kaggriculture\n\n"
        "Open `revenue/kaggriculture/cloud-harvest/CLAUDE_PROMPT.md`, then README.md.\n"
        "The source/engine package is ready for testing; new variants are unmeasured.\n"
        "Preserve the successful existing competition entry and peer-owned paths.\n"
    ).encode()
    files["BUNDLE_SHA256.json"] = (json.dumps({name: hashlib.sha256(data).hexdigest()
        for name, data in sorted(files.items())}, indent=2) + "\n").encode()
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 9, 7, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
    return {"path": str(output), "files": len(files),
            "sha256": hashlib.sha256(output.read_bytes()).hexdigest()}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--engine-dir", type=Path)
    args = parser.parse_args()
    print(json.dumps(bundle(args.output, args.engine_dir), indent=2))
