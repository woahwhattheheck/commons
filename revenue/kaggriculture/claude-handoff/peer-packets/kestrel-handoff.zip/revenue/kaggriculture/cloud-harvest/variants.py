"""Unmeasured harvest hypotheses for Sanskrit Juggernaut -> Claude.

Generate complete stdlib agents from a hash-pinned lean20 baseline. No games,
downloads or submission side effects occur in this module.
"""
from __future__ import annotations
import argparse
import hashlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE_SHA256 = "d9487c031b50ede06a706acc8bcb40e0b5a681d9b5e92c1a1a96492b26c2dd62"
VARIANTS = {
    "lean20_control": (),
    "crop_timing": ("crop_timing",),
    "terminal_routes": ("terminal_routes",),
    "same_turn_sales": ("same_turn_sales",),
    "combined": ("crop_timing", "terminal_routes", "same_turn_sales"),
}

SALE_HELPER = '''
def deposit_sales(orders, actions, units, inventories, shed, depot,
                  shed_capacity, wheat_keep, ending):
    """Quote only goods available after the chosen pickup/drop actions.

    The official interpreter applies unit actions in index order, then market
    orders. DROP discards overflow. It never sells directly from a worker.
    Planning cash remains the original conservative pre-action estimate.
    """
    projected = dict(shed)
    for index, (pos, action) in enumerate(zip(units, actions)):
        if tuple(pos) not in depot or not action:
            continue
        if action[0] == "PICKUP" and len(action) >= 3:
            item, quantity = action[1:3]
            projected[item] = max(0, projected.get(item, 0) - quantity)
        elif action[0] == "DROP":
            for item, quantity in inventories[index].items():
                room = max(0, shed_capacity - sum(projected.values()))
                projected[item] = projected.get(item, 0) + min(max(0, quantity), room)
    sales = []
    for product in PRODUCTS:
        quantity = projected.get(product, 0)
        if product == "WHEAT" and not ending:
            quantity = max(0, quantity - wheat_keep - 2)
        if quantity:
            sales.append(["SELL", product, quantity])
    return sales + [order for order in orders if order[0] != "SELL"]

'''


def replace_once(source, old, new):
    if source.count(old) != 1:
        raise ValueError("Frozen source span changed: " + old[:80])
    return source.replace(old, new, 1)


def build(name):
    if name not in VARIANTS:
        raise ValueError("Unknown variant: " + name)
    data = (HERE / "baselines/lean20.py").read_bytes()
    if hashlib.sha256(data).hexdigest() != BASE_SHA256:
        raise ValueError("Frozen lean20 bytes changed")
    source = data.decode("utf-8")
    changes = VARIANTS[name]
    if "crop_timing" in changes:
        source = replace_once(source,
            'CROPS = {"WHEAT": (10, 2, 4, 4), "CARROT": (20, 2, 3, 3),\n'
            '         "MELON": (80, 10, 10, 6)}',
            '# Cost, first harvest day, full-yield day, maximum yield: official pin.\n'
            'CROPS = {"WHEAT": (10, 2, 4, 6), "CARROT": (20, 2, 3, 4),\n'
            '         "MELON": (80, 10, 12, 6)}')
    if "terminal_routes" in changes:
        source = replace_once(source, 'remaining_turns <= d_home + 3:',
                              'remaining_turns <= d_home + 1:')
        source = replace_once(source,
            '+ 1 > remaining_turns:', '+ 1 > remaining_turns + 1:')
        source = replace_once(source,
            'carried_value*(1.4 if ending else .2)',
            'carried_value*(.25 if ending else .2)')
    if "same_turn_sales" in changes:
        source = replace_once(source, '\ndef agent(obs, configuration=None):',
                              '\n' + SALE_HELPER + '\ndef agent(obs, configuration=None):')
        source = replace_once(source,
            '    return {"farmer": actions[0], "hands": actions[1:], "market": orders[:10]}',
            '    orders = deposit_sales(orders, actions, units, inventories, shed, set(depot),\n'
            '                           _cfg(configuration, "shedCapacity", 100), wheat_keep, ending)\n'
            '    return {"farmer": actions[0], "hands": actions[1:], "market": orders[:10]}')
    compile(source, name + ".py", "exec")
    return source


def generate(directory):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    hashes = {}
    for name in VARIANTS:
        source = build(name).encode("utf-8")
        path = directory / (name + ".py")
        path.write_bytes(source)
        hashes[name] = hashlib.sha256(source).hexdigest()
    return hashes


if __name__ == "__main__":
    import json
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(generate(args.output), indent=2))
