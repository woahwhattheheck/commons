#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
output_dir="${1:-/tmp/rowan-validation}"
mkdir -p "$output_dir"
if [ ! -e "$output_dir/selection.json" ]; then
  cp revenue/kaggriculture/cloud-dispatch/selection.json "$output_dir/selection.json"
fi
cmp revenue/kaggriculture/cloud-dispatch/selection.json "$output_dir/selection.json"
python revenue/kaggriculture/cloud-dispatch/study.py validation --output "$output_dir" --engine-dir engine --workers 2
