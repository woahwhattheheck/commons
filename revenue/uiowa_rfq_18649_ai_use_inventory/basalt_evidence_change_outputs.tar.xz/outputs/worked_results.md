# What changes an AI-use claim?

All records and modifications are fictional. No University inputs or findings.

The original engine was executed for each variant. These are input interpretations, not verified adoption.

| Variant | Engine classification | Target gaps | Whole-collection gaps |
| --- | --- | ---: | ---: |
| baseline | UNSUPPORTED_CLAIM | 6 | 19 |
| locator_only | INFORMAL_EXPERIMENT | 4 | 17 |
| named_output | ACTIVE_USE | 4 | 17 |
| explicit_standalone | INFORMAL_EXPERIMENT | 3 | 16 |
| workflow_recorded | ACTIVE_USE | 3 | 16 |
| benefit_example | ACTIVE_USE | 2 | 15 |
| still_declared_planned | PLANNED_USE | 3 | 16 |

A named output can receive ACTIVE_USE while integration remains UNKNOWN. Explicit NONE_REPORTED changes that result; neither state proves approval or benefit.

Supplying a benefit example locator does not verify the locator or establish quantified time savings. A PLANNED declaration remains PLANNED_USE even with contradictory outputs.

## Exact inputs, reasons and next questions

### baseline

Changes from the unchanged baseline:

```json
{}
```

Engine reasons: use asserted (ACTIVE) with no evidence locator, no benefit example and no named output

Remaining gap codes: NO_CONCRETE_EXAMPLE, UNSUPPORTED_BENEFIT, UNKNOWN_INTEGRATION, NO_LIMITATIONS_CAPTURED, UNKNOWN_USER_COUNT, NO_EVIDENCE_LOCATOR

Actual follow-up probes: P-EX-01: You described this as in use. Walk me through the single most recent time, and tell me what it produced.; P-EX-02: Is there anything still on disk or in a queue from that use that I could record a locator for?; P-BEN-01: You mentioned a saving. What task was it, and how long did that task take the last time it was done both ways?; P-INT-01: When you use it, do you switch to another application first? If so, which one?; P-LIM-01: Has anyone had to redo work because of an output from this? Describe that case.; P-USR-01: Which roles, and about how many people in each? A range is fine; UNKNOWN is fine.; P-LOC-01: Where would I look to see this for myself? A folder, a board, a repository -- a pointer is enough.

### locator_only

Changes from the unchanged baseline:

```json
{
  "evidence_refs": [
    "synthetic://uiowa-rfq18649/AIU-SYN-003/release-note-example"
  ]
}
```

Engine reasons: no named output; recorded as an informal experiment rather than active use

Remaining gap codes: UNSUPPORTED_BENEFIT, UNKNOWN_INTEGRATION, NO_LIMITATIONS_CAPTURED, UNKNOWN_USER_COUNT

Actual follow-up probes: P-BEN-01: You mentioned a saving. What task was it, and how long did that task take the last time it was done both ways?; P-INT-01: When you use it, do you switch to another application first? If so, which one?; P-LIM-01: Has anyone had to redo work because of an output from this? Describe that case.; P-USR-01: Which roles, and about how many people in each? A range is fine; UNKNOWN is fine.

### named_output

Changes from the unchanged baseline:

```json
{
  "evidence_refs": [
    "synthetic://uiowa-rfq18649/AIU-SYN-003/release-note-example"
  ],
  "outputs": [
    "Fictional release-note document SYN-003"
  ]
}
```

Engine reasons: No classification reason was emitted.

Remaining gap codes: UNSUPPORTED_BENEFIT, UNKNOWN_INTEGRATION, NO_LIMITATIONS_CAPTURED, UNKNOWN_USER_COUNT

Actual follow-up probes: P-BEN-01: You mentioned a saving. What task was it, and how long did that task take the last time it was done both ways?; P-INT-01: When you use it, do you switch to another application first? If so, which one?; P-LIM-01: Has anyone had to redo work because of an output from this? Describe that case.; P-USR-01: Which roles, and about how many people in each? A range is fine; UNKNOWN is fine.

### explicit_standalone

Changes from the unchanged baseline:

```json
{
  "evidence_refs": [
    "synthetic://uiowa-rfq18649/AIU-SYN-003/release-note-example"
  ],
  "integrations": [],
  "outputs": [
    "Fictional release-note document SYN-003"
  ]
}
```

Engine reasons: explicitly not integrated into a workflow; recorded as an informal experiment rather than active use

Remaining gap codes: UNSUPPORTED_BENEFIT, NO_LIMITATIONS_CAPTURED, UNKNOWN_USER_COUNT

Actual follow-up probes: P-BEN-01: You mentioned a saving. What task was it, and how long did that task take the last time it was done both ways?; P-LIM-01: Has anyone had to redo work because of an output from this? Describe that case.; P-USR-01: Which roles, and about how many people in each? A range is fine; UNKNOWN is fine.

### workflow_recorded

Changes from the unchanged baseline:

```json
{
  "evidence_refs": [
    "synthetic://uiowa-rfq18649/AIU-SYN-003/release-note-example"
  ],
  "integrations": [
    "Fictional release-note publication workflow"
  ],
  "outputs": [
    "Fictional release-note document SYN-003"
  ]
}
```

Engine reasons: No classification reason was emitted.

Remaining gap codes: UNSUPPORTED_BENEFIT, NO_LIMITATIONS_CAPTURED, UNKNOWN_USER_COUNT

Actual follow-up probes: P-BEN-01: You mentioned a saving. What task was it, and how long did that task take the last time it was done both ways?; P-LIM-01: Has anyone had to redo work because of an output from this? Describe that case.; P-USR-01: Which roles, and about how many people in each? A range is fine; UNKNOWN is fine.

### benefit_example

Changes from the unchanged baseline:

```json
{
  "evidence_refs": [
    "synthetic://uiowa-rfq18649/AIU-SYN-003/release-note-example"
  ],
  "integrations": [
    "Fictional release-note publication workflow"
  ],
  "observed_benefits": [
    {
      "claim": "release notes go out much faster than they used to",
      "example_ref": "synthetic://uiowa-rfq18649/AIU-SYN-003/before-after-example"
    }
  ],
  "outputs": [
    "Fictional release-note document SYN-003"
  ]
}
```

Engine reasons: No classification reason was emitted.

Remaining gap codes: NO_LIMITATIONS_CAPTURED, UNKNOWN_USER_COUNT

Actual follow-up probes: P-LIM-01: Has anyone had to redo work because of an output from this? Describe that case.; P-USR-01: Which roles, and about how many people in each? A range is fine; UNKNOWN is fine.

### still_declared_planned

Changes from the unchanged baseline:

```json
{
  "declared_status": "PLANNED",
  "evidence_refs": [
    "synthetic://uiowa-rfq18649/AIU-SYN-003/release-note-example"
  ],
  "integrations": [
    "Fictional release-note publication workflow"
  ],
  "observed_benefits": [
    {
      "claim": "release notes go out much faster than they used to",
      "example_ref": "synthetic://uiowa-rfq18649/AIU-SYN-003/before-after-example"
    }
  ],
  "outputs": [
    "Fictional release-note document SYN-003"
  ]
}
```

Engine reasons: declared PLANNED but the record carries a concrete example; both readings preserved for a human to reconcile; benefits reported as observed for a use declared not-yet-started; these are projections until the use is running

Remaining gap codes: NO_LIMITATIONS_CAPTURED, UNKNOWN_USER_COUNT, STATUS_EVIDENCE_MISMATCH

Actual follow-up probes: P-LIM-01: Has anyone had to redo work because of an output from this? Describe that case.; P-USR-01: Which roles, and about how many people in each? A range is fine; UNKNOWN is fine.; P-MIS-01: The record says this has not started, but there is output from it. Which is it, and what changed?

## Captured source objects

```json
{
  "__init__.py": "7492aa62ce7bcb97d7953cf431590c9264407bf6",
  "fixtures/synthetic_ai_use.json": "42347c91fd9b6b3ce3e600487bd9a3d4632a83c9",
  "interview_guide.py": "8d29293e2adb6b795dbd9053a796fdf97d5a76c4",
  "inventory.py": "63b69064a871e54fc0eda806746eac747088328d",
  "schema.py": "0a7dbf5873681a2d9f77199b3aad0ec9fbf2a3a4"
}
```

Captured original engine API in a temporary cloud process; not hosted CI or source verification of the fictional locators.
