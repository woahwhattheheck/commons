#!/usr/bin/env python3
"""Local-first apparel catalog image studio.

The renderer never invents garment pixels. It decodes a source RGBA PNG, audits
operator-declared item facts against that exact source, then composites the source
onto procedurally generated mannequin/background scenes. Opaque source pixels are
copied byte-for-byte; soft-alpha edges use deterministic source-over composition.
"""
from __future__ import annotations

import argparse
import binascii
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import struct
import tempfile
import threading
import time
from typing import Any, Iterable
import zipfile
import zlib

PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
MAX_DIMENSION = 4096
MAX_PIXELS = 16_000_000
CANVAS_DEFAULT = (720, 720)

BACKGROUNDS = {
    "studio-white": (247, 247, 244),
    "sand": (226, 215, 195),
    "mist": (207, 219, 224),
    "sage": (195, 211, 193),
    "charcoal": (48, 51, 56),
}
MODELS = {
    "none": None,
    "neutral": (196, 171, 145),
    "warm": (167, 115, 79),
    "cool": (116, 89, 72),
    "deep": (83, 58, 45),
}
HEX_RE = re.compile(r"^#[0-9A-Fa-f]{6}$")
SAFE_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$")


class StudioError(ValueError):
    """Input or workspace data violates the studio contract."""


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise StudioError(message)


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True) + "\n"


def sha256_bytes(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def git_blob_sha(raw: bytes) -> str:
    return hashlib.sha1(f"blob {len(raw)}\0".encode("ascii") + raw).hexdigest()


def _chunk(kind: bytes, data: bytes) -> bytes:
    crc = binascii.crc32(kind)
    crc = binascii.crc32(data, crc) & 0xFFFFFFFF
    return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", crc)


def encode_png(width: int, height: int, rgba: bytes) -> bytes:
    _require(0 < width <= MAX_DIMENSION and 0 < height <= MAX_DIMENSION, "invalid PNG dimensions")
    _require(width * height <= MAX_PIXELS, "PNG pixel count exceeds safety limit")
    _require(len(rgba) == width * height * 4, "RGBA byte count does not match dimensions")
    rows = bytearray()
    stride = width * 4
    for y in range(height):
        rows.append(0)
        rows.extend(rgba[y * stride:(y + 1) * stride])
    ihdr = struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)
    return PNG_SIGNATURE + _chunk(b"IHDR", ihdr) + _chunk(b"IDAT", zlib.compress(bytes(rows), 9)) + _chunk(b"IEND", b"")


def _paeth(a: int, b: int, c: int) -> int:
    p = a + b - c
    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
    if pa <= pb and pa <= pc:
        return a
    if pb <= pc:
        return b
    return c


def decode_png(raw: bytes) -> tuple[int, int, bytes]:
    _require(raw.startswith(PNG_SIGNATURE), "source must be a PNG file")
    pos = len(PNG_SIGNATURE)
    width = height = None
    idat = bytearray()
    saw_iend = False
    while pos < len(raw):
        _require(pos + 12 <= len(raw), "truncated PNG chunk")
        length = struct.unpack(">I", raw[pos:pos + 4])[0]
        kind = raw[pos + 4:pos + 8]
        start = pos + 8
        end = start + length
        _require(end + 4 <= len(raw), "truncated PNG chunk payload")
        data = raw[start:end]
        expected_crc = struct.unpack(">I", raw[end:end + 4])[0]
        actual_crc = binascii.crc32(kind)
        actual_crc = binascii.crc32(data, actual_crc) & 0xFFFFFFFF
        _require(expected_crc == actual_crc, f"PNG CRC mismatch in {kind.decode('latin1')}")
        if kind == b"IHDR":
            _require(width is None and length == 13, "invalid PNG IHDR")
            width, height, depth, color_type, compression, filtering, interlace = struct.unpack(">IIBBBBB", data)
            _require(depth == 8 and color_type == 6, "faithful mode requires 8-bit RGBA PNG input")
            _require((compression, filtering, interlace) == (0, 0, 0), "unsupported PNG encoding")
            _require(0 < width <= MAX_DIMENSION and 0 < height <= MAX_DIMENSION, "PNG dimensions exceed limit")
            _require(width * height <= MAX_PIXELS, "PNG pixel count exceeds safety limit")
        elif kind == b"IDAT":
            _require(width is not None, "PNG IDAT appears before IHDR")
            idat.extend(data)
            _require(len(idat) <= 64_000_000, "PNG compressed payload exceeds limit")
        elif kind == b"IEND":
            saw_iend = True
            pos = end + 4
            break
        pos = end + 4
    _require(width is not None and height is not None and saw_iend, "incomplete PNG")
    try:
        scan = zlib.decompress(bytes(idat))
    except zlib.error as exc:
        raise StudioError("invalid PNG compressed data") from exc
    stride = width * 4
    _require(len(scan) == (stride + 1) * height, "unexpected PNG scanline size")
    out = bytearray(width * height * 4)
    prev = bytearray(stride)
    cursor = 0
    for y in range(height):
        filter_type = scan[cursor]
        cursor += 1
        row = bytearray(scan[cursor:cursor + stride])
        cursor += stride
        _require(filter_type in (0, 1, 2, 3, 4), "unsupported PNG filter")
        for x in range(stride):
            left = row[x - 4] if x >= 4 else 0
            up = prev[x]
            up_left = prev[x - 4] if x >= 4 else 0
            if filter_type == 1:
                row[x] = (row[x] + left) & 0xFF
            elif filter_type == 2:
                row[x] = (row[x] + up) & 0xFF
            elif filter_type == 3:
                row[x] = (row[x] + ((left + up) // 2)) & 0xFF
            elif filter_type == 4:
                row[x] = (row[x] + _paeth(left, up, up_left)) & 0xFF
        out[y * stride:(y + 1) * stride] = row
        prev = row
    return width, height, bytes(out)


def rgba_at(rgba: bytes, width: int, x: int, y: int) -> tuple[int, int, int, int]:
    i = (y * width + x) * 4
    return tuple(rgba[i:i + 4])  # type: ignore[return-value]


def parse_hex(value: str, at: str = "color") -> tuple[int, int, int]:
    _require(isinstance(value, str) and HEX_RE.fullmatch(value) is not None, f"{at} must be #RRGGBB")
    return tuple(int(value[i:i + 2], 16) for i in (1, 3, 5))  # type: ignore[return-value]


def load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise StudioError(f"unable to read JSON {path}: {exc}") from exc
    _require(isinstance(value, dict), f"{path} must contain a JSON object")
    return value


def resolve_under(root: Path, relative: str) -> Path:
    _require(isinstance(relative, str) and relative and not os.path.isabs(relative), "source path must be relative")
    root = root.resolve()
    candidate = (root / relative).resolve()
    try:
        candidate.relative_to(root)
    except ValueError as exc:
        raise StudioError("source path escapes its workspace") from exc
    return candidate


def audit_garment(spec_path: Path) -> dict[str, Any]:
    spec = load_json(spec_path)
    root = spec_path.parent
    for key in ("sku", "name", "size", "source", "source_sha256"):
        _require(isinstance(spec.get(key), str) and spec[key].strip(), f"garment {key} must be nonempty text")
    _require(SAFE_ID_RE.fullmatch(spec["sku"]) is not None, "garment sku contains unsafe characters")
    source_path = resolve_under(root, spec["source"])
    try:
        raw = source_path.read_bytes()
    except OSError as exc:
        raise StudioError(f"unable to read garment source: {exc}") from exc
    actual_sha = sha256_bytes(raw)
    _require(actual_sha == spec["source_sha256"].lower(), "garment source SHA-256 does not match spec")
    width, height, rgba = decode_png(raw)
    expected_dims = spec.get("source_dimensions")
    _require(isinstance(expected_dims, list) and len(expected_dims) == 2 and all(isinstance(v, int) for v in expected_dims),
             "source_dimensions must be [width, height]")
    _require(expected_dims == [width, height], "garment source dimensions do not match spec")

    declared = spec.get("declared_colors", [])
    _require(isinstance(declared, list) and all(isinstance(v, str) for v in declared), "declared_colors must be a list of hex colors")
    opaque_colors = set()
    soft_alpha = 0
    visible = 0
    for i in range(0, len(rgba), 4):
        r, g, b, a = rgba[i:i + 4]
        if a:
            visible += 1
        if a == 255:
            opaque_colors.add((r, g, b))
        elif a:
            soft_alpha += 1
    for index, value in enumerate(declared):
        rgb = parse_hex(value, f"declared_colors[{index}]")
        _require(rgb in opaque_colors, f"declared color {value} is not present in an opaque source pixel")

    checks = spec.get("detail_checks", [])
    _require(isinstance(checks, list), "detail_checks must be a list")
    checked = []
    for index, check in enumerate(checks):
        _require(isinstance(check, dict), f"detail_checks[{index}] must be an object")
        label = check.get("label")
        x, y, color = check.get("x"), check.get("y"), check.get("color")
        _require(isinstance(label, str) and label.strip(), f"detail_checks[{index}].label must be text")
        _require(isinstance(x, int) and isinstance(y, int) and 0 <= x < width and 0 <= y < height,
                 f"detail_checks[{index}] coordinates are outside the source")
        expected_rgb = parse_hex(color, f"detail_checks[{index}].color")
        actual = rgba_at(rgba, width, x, y)
        _require(actual[3] > 0, f"detail check {label!r} points at a transparent pixel")
        _require(actual[:3] == expected_rgb, f"detail check {label!r} expected {color}, got #{actual[0]:02X}{actual[1]:02X}{actual[2]:02X}")
        checked.append({"label": label, "x": x, "y": y, "color": color.upper()})

    _require(visible > 0, "garment source has no visible pixels")
    return {
        "sku": spec["sku"],
        "name": spec["name"],
        "size": spec["size"],
        "source": spec["source"],
        "source_sha256": actual_sha,
        "source_git_blob": git_blob_sha(raw),
        "source_dimensions": [width, height],
        "visible_pixels": visible,
        "soft_alpha_pixels": soft_alpha,
        "declared_colors": [v.upper() for v in declared],
        "detail_checks": checked,
    }


def _canvas(width: int, height: int, rgb: tuple[int, int, int]) -> bytearray:
    return bytearray(bytes((*rgb, 255)) * (width * height))


def _set_pixel(buf: bytearray, width: int, height: int, x: int, y: int, rgb: tuple[int, int, int]) -> None:
    if 0 <= x < width and 0 <= y < height:
        i = (y * width + x) * 4
        buf[i:i + 4] = bytes((*rgb, 255))


def _rect(buf: bytearray, width: int, height: int, x0: int, y0: int, x1: int, y1: int, rgb: tuple[int, int, int]) -> None:
    x0, x1 = sorted((max(0, x0), min(width, x1)))
    y0, y1 = sorted((max(0, y0), min(height, y1)))
    if x1 <= x0 or y1 <= y0:
        return
    row = bytes((*rgb, 255)) * (x1 - x0)
    for y in range(y0, y1):
        i = (y * width + x0) * 4
        buf[i:i + len(row)] = row


def _ellipse(buf: bytearray, width: int, height: int, cx: int, cy: int, rx: int, ry: int, rgb: tuple[int, int, int]) -> None:
    if rx <= 0 or ry <= 0:
        return
    rx2, ry2 = rx * rx, ry * ry
    for y in range(max(0, cy - ry), min(height, cy + ry + 1)):
        dy2 = (y - cy) * (y - cy)
        for x in range(max(0, cx - rx), min(width, cx + rx + 1)):
            if (x - cx) * (x - cx) * ry2 + dy2 * rx2 <= rx2 * ry2:
                _set_pixel(buf, width, height, x, y, rgb)


def _background(name: str, width: int, height: int, accent: tuple[int, int, int]) -> bytearray:
    _require(name in BACKGROUNDS, f"unknown background {name!r}")
    base = BACKGROUNDS[name]
    buf = _canvas(width, height, base)
    # Simple deterministic studio depth treatment, kept outside source pixels.
    if name == "charcoal":
        floor = tuple(min(255, c + 16) for c in base)
    else:
        floor = tuple(max(0, c - 10) for c in base)
    _rect(buf, width, height, 0, int(height * 0.78), width, height, floor)
    # Accent rails create brand consistency without touching the garment layer.
    _rect(buf, width, height, 0, 0, width, 10, accent)
    _rect(buf, width, height, 0, height - 10, width, height, accent)
    return buf


def _model(buf: bytearray, width: int, height: int, name: str) -> None:
    _require(name in MODELS, f"unknown model style {name!r}")
    tone = MODELS[name]
    if tone is None:
        return
    cx = width // 2
    _ellipse(buf, width, height, cx, int(height * 0.18), int(width * 0.055), int(height * 0.055), tone)
    _ellipse(buf, width, height, cx, int(height * 0.44), int(width * 0.17), int(height * 0.26), tone)
    _rect(buf, width, height, cx - int(width * 0.12), int(height * 0.58), cx - int(width * 0.035), int(height * 0.93), tone)
    _rect(buf, width, height, cx + int(width * 0.035), int(height * 0.58), cx + int(width * 0.12), int(height * 0.93), tone)
    _rect(buf, width, height, cx - int(width * 0.27), int(height * 0.29), cx - int(width * 0.12), int(height * 0.62), tone)
    _rect(buf, width, height, cx + int(width * 0.12), int(height * 0.29), cx + int(width * 0.27), int(height * 0.62), tone)


def _blend_source(buf: bytearray, canvas_w: int, canvas_h: int, src_w: int, src_h: int, src: bytes, x0: int, y0: int) -> dict[str, int]:
    _require(x0 >= 0 and y0 >= 0 and x0 + src_w <= canvas_w and y0 + src_h <= canvas_h,
             "garment placement falls outside canvas; faithful mode does not rescale")
    opaque = soft = visible = 0
    for sy in range(src_h):
        for sx in range(src_w):
            si = (sy * src_w + sx) * 4
            r, g, b, a = src[si:si + 4]
            if a == 0:
                continue
            visible += 1
            dx, dy = x0 + sx, y0 + sy
            di = (dy * canvas_w + dx) * 4
            if a == 255:
                buf[di:di + 4] = bytes((r, g, b, 255))
                opaque += 1
            else:
                br, bg, bb, _ = buf[di:di + 4]
                inv = 255 - a
                buf[di:di + 4] = bytes(((r * a + br * inv + 127) // 255,
                                        (g * a + bg * inv + 127) // 255,
                                        (b * a + bb * inv + 127) // 255, 255))
                soft += 1
    return {"visible_source_pixels": visible, "opaque_pixels_copied_exact": opaque, "soft_alpha_pixels_composited": soft}


def _load_preset(path: Path) -> dict[str, Any]:
    preset = load_json(path)
    for key in ("id", "brand", "accent"):
        _require(isinstance(preset.get(key), str) and preset[key].strip(), f"preset {key} must be nonempty text")
    _require(SAFE_ID_RE.fullmatch(preset["id"]) is not None, "preset id contains unsafe characters")
    parse_hex(preset["accent"], "preset accent")
    canvas = preset.get("canvas", list(CANVAS_DEFAULT))
    _require(isinstance(canvas, list) and len(canvas) == 2 and all(isinstance(v, int) for v in canvas), "preset canvas must be [width,height]")
    _require(320 <= canvas[0] <= 2048 and 320 <= canvas[1] <= 2048, "preset canvas dimensions must be 320..2048")
    scenes = preset.get("scenes")
    _require(isinstance(scenes, list) and 1 <= len(scenes) <= 50, "preset scenes must contain 1..50 entries")
    normalized = []
    for i, scene in enumerate(scenes):
        _require(isinstance(scene, dict), f"scene[{i}] must be an object")
        bg, model = scene.get("background"), scene.get("model")
        _require(bg in BACKGROUNDS, f"scene[{i}].background is unknown")
        _require(model in MODELS, f"scene[{i}].model is unknown")
        normalized.append({"background": bg, "model": model})
    return {**preset, "canvas": canvas, "scenes": normalized}


def render_scene(spec_path: Path, preset_path: Path, scene: dict[str, str], output: Path, *, offset_x: int = 0, offset_y: int = 0) -> dict[str, Any]:
    audit = audit_garment(spec_path)
    spec = load_json(spec_path)
    preset = _load_preset(preset_path)
    raw = resolve_under(spec_path.parent, spec["source"]).read_bytes()
    src_w, src_h, src = decode_png(raw)
    canvas_w, canvas_h = preset["canvas"]
    _require(src_w <= canvas_w and src_h <= canvas_h, "source garment is larger than canvas; faithful mode refuses resampling")
    _require(isinstance(offset_x, int) and isinstance(offset_y, int), "offsets must be integers")
    x0 = (canvas_w - src_w) // 2 + offset_x
    y0 = (canvas_h - src_h) // 2 + offset_y
    accent = parse_hex(preset["accent"], "preset accent")
    buf = _background(scene["background"], canvas_w, canvas_h, accent)
    _model(buf, canvas_w, canvas_h, scene["model"])
    fidelity = _blend_source(buf, canvas_w, canvas_h, src_w, src_h, src, x0, y0)
    rendered = encode_png(canvas_w, canvas_h, bytes(buf))
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(rendered)
    # Decode our own bytes and re-check every fully opaque source pixel exactly.
    out_w, out_h, out_rgba = decode_png(rendered)
    _require((out_w, out_h) == (canvas_w, canvas_h), "rendered dimensions changed unexpectedly")
    checked = 0
    for sy in range(src_h):
        for sx in range(src_w):
            pixel = rgba_at(src, src_w, sx, sy)
            if pixel[3] == 255:
                _require(rgba_at(out_rgba, out_w, x0 + sx, y0 + sy) == pixel,
                         "opaque garment pixel changed during render")
                checked += 1
    _require(checked == fidelity["opaque_pixels_copied_exact"], "opaque-pixel audit count changed")
    return {
        "file": output.name,
        "sha256": sha256_bytes(rendered),
        "git_blob": git_blob_sha(rendered),
        "bytes": len(rendered),
        "scene": dict(scene),
        "canvas": [canvas_w, canvas_h],
        "placement": [x0, y0],
        "source_sha256": audit["source_sha256"],
        "source_dimensions": audit["source_dimensions"],
        "source_detail_checks": len(audit["detail_checks"]),
        "garment_size": audit["size"],
        **fidelity,
        "opaque_pixel_fidelity": "BYTE_EXACT_RGBA",
        "soft_alpha_policy": "SOURCE_OVER_NO_RESAMPLE",
    }


def _write_zip(path: Path, files: Iterable[tuple[str, bytes]]) -> None:
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, raw in sorted(files):
            info = zipfile.ZipInfo(name, (2026, 9, 8, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            info.create_system = 3
            archive.writestr(info, raw)


def build_catalog(spec_path: Path, preset_path: Path, output_dir: Path) -> dict[str, Any]:
    audit = audit_garment(spec_path)
    preset = _load_preset(preset_path)
    _require(len(preset["scenes"]) == 10, "paid ten-image pack requires exactly 10 preset scenes")
    output_dir = output_dir.resolve()
    _require(not output_dir.exists(), f"output directory already exists: {output_dir}")
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix=output_dir.name + ".stage-", dir=output_dir.parent))
    try:
        images = []
        for index, scene in enumerate(preset["scenes"], 1):
            file_name = f"{index:02d}-{scene['background']}-{scene['model']}.png"
            entry = render_scene(spec_path, preset_path, scene, stage / "images" / file_name)
            images.append(entry)
        source_raw = resolve_under(spec_path.parent, load_json(spec_path)["source"]).read_bytes()
        (stage / "source").mkdir(parents=True)
        (stage / "source" / "garment.png").write_bytes(source_raw)
        (stage / "source" / "garment.json").write_text(spec_path.read_text(encoding="utf-8"), encoding="utf-8")
        (stage / "source" / "brand-preset.json").write_text(preset_path.read_text(encoding="utf-8"), encoding="utf-8")
        manifest = {
            "schema": "apparel-catalog-image-studio/v1",
            "offer": {"ten_image_pack_usd": 99, "recurring_monthly_usd": 299},
            "brand": preset["brand"],
            "preset_id": preset["id"],
            "garment": audit,
            "image_count": len(images),
            "images": images,
            "truth": {
                "authorized_or_synthetic_source_required": True,
                "source_pixels_resampled": False,
                "opaque_garment_pixels_modified": False,
                "generated_scene_is_not_a_real_person": True,
                "external_uploads": 0,
                "customer_approval_claimed": False,
            },
        }
        manifest_raw = canonical_json(manifest).encode("utf-8")
        (stage / "manifest.json").write_bytes(manifest_raw)
        csv_buf = io.StringIO(newline="")
        writer = csv.writer(csv_buf, lineterminator="\n")
        writer.writerow(["file", "background", "model", "sha256", "source_sha256", "sku", "size", "opaque_pixel_fidelity"])
        for row in images:
            writer.writerow([row["file"], row["scene"]["background"], row["scene"]["model"], row["sha256"], row["source_sha256"], audit["sku"], audit["size"], row["opaque_pixel_fidelity"]])
        (stage / "catalog.csv").write_text(csv_buf.getvalue(), encoding="utf-8", newline="")
        bundle_files = []
        for file in stage.rglob("*"):
            if file.is_file() and file.name != "catalog.zip":
                bundle_files.append((file.relative_to(stage).as_posix(), file.read_bytes()))
        _write_zip(stage / "catalog.zip", bundle_files)
        os.replace(stage, output_dir)
        return manifest
    except Exception:
        shutil.rmtree(stage, ignore_errors=True)
        raise


class StudioStore:
    """SQLite project/revision store with optimistic revision checks."""

    def __init__(self, path: Path):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.db = sqlite3.connect(path, timeout=5, isolation_level=None, check_same_thread=False)
        self.db.execute("PRAGMA foreign_keys=ON")
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS projects (
                id TEXT PRIMARY KEY,
                sku TEXT NOT NULL,
                source_rel TEXT NOT NULL,
                spec_json TEXT NOT NULL,
                preset_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS revisions (
                project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                revision INTEGER NOT NULL,
                background TEXT NOT NULL,
                model TEXT NOT NULL,
                offset_x INTEGER NOT NULL,
                offset_y INTEGER NOT NULL,
                note TEXT NOT NULL,
                created_at TEXT NOT NULL,
                PRIMARY KEY(project_id, revision)
            );
        """)

    def close(self) -> None:
        with self.lock:
            self.db.close()

    def create_project(self, project_id: str, spec: dict[str, Any], preset: dict[str, Any], source_rel: str, *, created_at: str | None = None) -> dict[str, Any]:
        _require(SAFE_ID_RE.fullmatch(project_id or "") is not None, "project id is invalid")
        _require(isinstance(source_rel, str) and source_rel, "project source_rel must be text")
        _require(isinstance(spec.get("sku"), str) and spec["sku"], "project spec requires sku")
        _require(isinstance(preset.get("id"), str) and preset["id"], "project preset requires id")
        stamp = created_at or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        try:
            with self.lock:
                self.db.execute("BEGIN IMMEDIATE")
                self.db.execute("INSERT INTO projects(id,sku,source_rel,spec_json,preset_json,created_at) VALUES(?,?,?,?,?,?)",
                                (project_id, spec["sku"], source_rel, canonical_json(spec), canonical_json(preset), stamp))
                first_scene = preset.get("scenes", [{"background": "studio-white", "model": "none"}])[0]
                self.db.execute("INSERT INTO revisions VALUES(?,?,?,?,?,?,?,?)",
                                (project_id, 1, first_scene["background"], first_scene["model"], 0, 0, "initial", stamp))
                self.db.execute("COMMIT")
        except sqlite3.IntegrityError as exc:
            with self.lock:
                if self.db.in_transaction:
                    self.db.execute("ROLLBACK")
            raise StudioError(f"project already exists: {project_id}") from exc
        except Exception:
            with self.lock:
                if self.db.in_transaction:
                    self.db.execute("ROLLBACK")
            raise
        return self.get_project(project_id)

    def get_project(self, project_id: str) -> dict[str, Any]:
        with self.lock:
            row = self.db.execute("SELECT id,sku,source_rel,spec_json,preset_json,created_at FROM projects WHERE id=?", (project_id,)).fetchone()
            _require(row is not None, f"unknown project {project_id!r}")
            revisions = self.db.execute("SELECT revision,background,model,offset_x,offset_y,note,created_at FROM revisions WHERE project_id=? ORDER BY revision", (project_id,)).fetchall()
        return {
            "id": row[0], "sku": row[1], "source_rel": row[2],
            "spec": json.loads(row[3]), "preset": json.loads(row[4]), "created_at": row[5],
            "revisions": [
                {"revision": r[0], "background": r[1], "model": r[2], "offset_x": r[3], "offset_y": r[4], "note": r[5], "created_at": r[6]}
                for r in revisions
            ],
        }

    def revise(self, project_id: str, *, expected_revision: int, background: str, model: str, offset_x: int = 0, offset_y: int = 0, note: str = "", created_at: str | None = None) -> dict[str, Any]:
        _require(background in BACKGROUNDS, "unknown background")
        _require(model in MODELS, "unknown model")
        _require(isinstance(expected_revision, int) and expected_revision >= 1, "expected_revision must be a positive integer")
        _require(isinstance(offset_x, int) and isinstance(offset_y, int) and abs(offset_x) <= 200 and abs(offset_y) <= 200, "offsets must be integers within +/-200")
        _require(isinstance(note, str) and len(note) <= 1000, "revision note is too long")
        stamp = created_at or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        try:
            with self.lock:
                self.db.execute("BEGIN IMMEDIATE")
                row = self.db.execute("SELECT MAX(revision) FROM revisions WHERE project_id=?", (project_id,)).fetchone()
                _require(row and row[0] is not None, f"unknown project {project_id!r}")
                current = int(row[0])
                _require(current == expected_revision, f"revision conflict: expected {expected_revision}, current {current}")
                next_revision = current + 1
                self.db.execute("INSERT INTO revisions VALUES(?,?,?,?,?,?,?,?)",
                                (project_id, next_revision, background, model, offset_x, offset_y, note, stamp))
                self.db.execute("COMMIT")
        except Exception:
            with self.lock:
                if self.db.in_transaction:
                    self.db.execute("ROLLBACK")
            raise
        return self.get_project(project_id)


def _sample_garment_rgba(width: int = 240, height: int = 280) -> bytes:
    # Transparent canvas with an original synthetic tee, seam, collar, logo and size tab.
    buf = bytearray(b"\x00" * (width * height * 4))
    navy = (28, 52, 88)
    seam = (230, 230, 220)
    logo = (242, 194, 55)
    tab = (239, 239, 239)
    def paint(x0: int, y0: int, x1: int, y1: int, rgb: tuple[int, int, int]) -> None:
        for y in range(max(0, y0), min(height, y1)):
            for x in range(max(0, x0), min(width, x1)):
                i = (y * width + x) * 4
                buf[i:i + 4] = bytes((*rgb, 255))
    # Body + sleeves.
    paint(55, 48, 185, 242, navy)
    paint(22, 64, 55, 143, navy)
    paint(185, 64, 218, 143, navy)
    # Collar cutout (transparent) then light seam around it.
    paint(92, 48, 148, 65, seam)
    paint(98, 48, 142, 62, (0, 0, 0))
    # restore alpha=0 for cutout
    for y in range(48, 62):
        for x in range(98, 142):
            i = (y * width + x) * 4
            buf[i:i + 4] = b"\x00\x00\x00\x00"
    # Bottom seam.
    paint(55, 232, 185, 236, seam)
    # Logo block and two interior marks.
    paint(92, 107, 148, 147, logo)
    paint(103, 116, 109, 138, navy)
    paint(131, 116, 137, 138, navy)
    # Size tab.
    paint(111, 66, 129, 78, tab)
    paint(117, 69, 123, 75, navy)
    return bytes(buf)


def create_sample(root: Path) -> dict[str, Path]:
    _require(not root.exists(), f"sample directory already exists: {root}")
    root.mkdir(parents=True)
    source = encode_png(240, 280, _sample_garment_rgba())
    (root / "garment.png").write_bytes(source)
    spec = {
        "sku": "SYN-TEE-001",
        "name": "Synthetic navy catalog tee",
        "size": "M",
        "source": "garment.png",
        "source_sha256": sha256_bytes(source),
        "source_dimensions": [240, 280],
        "declared_colors": ["#1C3458", "#F2C237", "#E6E6DC", "#EFEFEF"],
        "detail_checks": [
            {"label": "body navy", "x": 70, "y": 100, "color": "#1C3458"},
            {"label": "bottom seam", "x": 80, "y": 233, "color": "#E6E6DC"},
            {"label": "logo gold", "x": 95, "y": 110, "color": "#F2C237"},
            {"label": "size tab", "x": 112, "y": 67, "color": "#EFEFEF"},
        ],
        "rights": "synthetic-original",
    }
    preset = {
        "id": "threadline-demo",
        "brand": "Threadline Demo",
        "accent": "#F2C237",
        "canvas": [720, 720],
        "scenes": [
            {"background": "studio-white", "model": "neutral"},
            {"background": "studio-white", "model": "warm"},
            {"background": "sand", "model": "neutral"},
            {"background": "sand", "model": "deep"},
            {"background": "mist", "model": "cool"},
            {"background": "mist", "model": "none"},
            {"background": "sage", "model": "warm"},
            {"background": "sage", "model": "deep"},
            {"background": "charcoal", "model": "neutral"},
            {"background": "charcoal", "model": "none"},
        ],
    }
    (root / "garment.json").write_text(canonical_json(spec), encoding="utf-8")
    (root / "brand-preset.json").write_text(canonical_json(preset), encoding="utf-8")
    return {"garment": root / "garment.json", "preset": root / "brand-preset.json", "source": root / "garment.png"}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("sample", help="create the original synthetic garment and ten-image catalog")
    p.add_argument("output", type=Path)
    p = sub.add_parser("audit", help="audit a garment spec against its exact source PNG")
    p.add_argument("garment", type=Path)
    p = sub.add_parser("catalog", help="build a deterministic ten-image catalog")
    p.add_argument("garment", type=Path)
    p.add_argument("preset", type=Path)
    p.add_argument("output", type=Path)
    args = parser.parse_args(argv)
    try:
        if args.command == "sample":
            sample_root = args.output.resolve()
            parts = create_sample(sample_root / "source")
            manifest = build_catalog(parts["garment"], parts["preset"], sample_root / "catalog")
            print(canonical_json(manifest), end="")
        elif args.command == "audit":
            print(canonical_json(audit_garment(args.garment)), end="")
        elif args.command == "catalog":
            print(canonical_json(build_catalog(args.garment, args.preset, args.output)), end="")
        return 0
    except (StudioError, OSError, sqlite3.Error) as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    raise SystemExit(main())
