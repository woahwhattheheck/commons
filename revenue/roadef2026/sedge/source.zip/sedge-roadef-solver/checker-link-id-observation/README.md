# Synthetic link-ID observation

The original unequal-branch ECMP fixture uses node IDs 101, 111, ... and link IDs
37, 44, ... . At slot 1, the scenario removes link ID 37 (101 -> 111).
The solver's empty-waypoint prediction raises 101 -> 121 to 1.0 and removes traffic
from 101 -> 111, matching the documented intervention meaning.

The unmodified official v1.2.2 checker returned `valid: true` and unchanged slot-1
loads (0.5 on both source branches). Exact input files and both outputs are retained.
All 12 public set-B checks passed with matching loads; this synthetic discrepancy
is outside those public cases. The regular behavior fixture uses contiguous link IDs
to test forwarding against the current checker, while preserving noncontiguous node IDs.

This is a compatibility observation awaiting organizer clarification. The checker
was not modified and no upstream report was submitted by this build session.
